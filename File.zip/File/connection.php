<?php
$con = mysqli_connect("localhost", "root", "", "gwcl");
$errors = array(); 
?>