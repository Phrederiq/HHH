<?php


if(!$con = mysqli_connect("localhost", "root", "", "gwcl"))
{
    die("failed to connect");
}
?>