<?php
 session_start();


 header("location: dashboard.php");
 $uname=$_GET['uname'];

 $mail=$_GET['mail'];
 $pw=$_GET['pw'];

 $conn = mysqli_connect('localhost','root', '', 'shop');




 //sql code 
$sql = "SELECT * FROM `login` WHERE eMail = '$mail' and passWord = '$pw' ";


//this is to execute the command
$result=mysqli_query($con,$sql);


// count the number of records 
$count=mysqli_num_rows($result);








 $sql= "INSERT INTO `store`(`USERNAME`, `EMAIL`, `PASSWORD`) VALUES ('$uname','$mail','$pw')";

 $_SESSION ['username'] = $uname; 
 $_SESSION ['email'] = $mail; 
 $_SESSION ['password'] = $pw; 




 
//  $_SESSION ['mail1'];
// $_SESSION ['pw1'];

 
mysqli_query($conn,$sql);


?>