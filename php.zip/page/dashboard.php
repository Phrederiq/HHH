<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    

<?PHP


session_start();
// echo $_SESSION ['username'];  
// echo $_SESSION ['email'];
// echo $_SESSION ['password'];


?>
<p>YOUR ACCOUNT HAS BEEN CREATED </p>
<h1>Please login</h1>
<form action="page1.php" method="get">

            <label > EMAIL</label><br>
            <input type="mail" name="mail1" ><br>
            <label > PASSWORD</label><br>
            <input type="password" name="pw1" ><br>
            <input type="submit" value="submit"><br>
</form>
<?php 



 
?>
<p> <a href="logout.php">Logout</a> </p>

</body>
</html>
