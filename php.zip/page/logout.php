<?PHP


session_destroy();

header("location: page1.php");

?>

