<?php

session_start();
$_SESSION ['mail1'];
$_SESSION ['pw1'];
$_SESSION ['email']; 
 $_SESSION ['password'];
 
if ($mail= $mail1 && $pw= $pw1  ){ 
    header("location:my.php");

 }
 else {
     echo "INVALID INPUT ";
 }


?>