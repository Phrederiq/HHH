<?php
session_start();

session_start();
include("connection.php");
include("function.php");

$user_data = check_login($con);



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login</title>
</head>
<body>
    
<form method="POST">
    <input type="text" name="user_name"> <br>
    <input type="password" name="password"><br>

    <input type="submit" value="login"><br>
    <a href="signup.php">Signup</a>


</form>
</body>
</html>