<?php

// $dbhost ="localhost";
// $dbuser ="root";
// $dbpass ="";
// $dbname ="church_db";

if (!$con = mysqli_connect("localhost", "root", "", "church_db"))
{
    die("failed to connect!");
}
?>