<?php
echo $num1=2;
echo $num2=5;
$total;


















?>
