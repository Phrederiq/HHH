<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>CALCULATOR</h1>
    <!-- <form action="processor.php" method="GET">
        <label for="name">FIRSTNAME</label><br>
        <input type="text"  id="fname" name="fname"><br>
        <label for="name">LASTNAME</label><br>
        <input type="text"  id="lname" name="lname" ><br>
        <label for="name">AGE</label><br>
        <input type="text"  id="name" name ="age"><br>
        <label for="name">Password</label><br>
        <input type="password"  id="pword" name ="password"><br><br>
        <input type="submit" value="submit">
        </form> -->

        <form action="processor.php" method="GET">
        <label> ENTER FIRST NUMBER</label><br>
        <input type ="number" name="num1"> <br>
        <label> ENTER OPERATOR</label><br>
        <input type ="number" name="OPP"> <br>
        <label> ENTER LAST NUMBER</label><br>
        <input type ="number" name="num2"> <br>
        <input type="submit" value="ENTER">
        </form>



        
</body>
</html>