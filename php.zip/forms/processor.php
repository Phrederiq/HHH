<?php

// echo $firstname= $_GET['fname'];
// echo $lastname= $_GET['lname'];
// echo $age= $_GET['age'];
// echo $password = $_GET['password'];

//echo "data has gotten here";

$num1= $_GET['num1'];
$num2= $_GET['num2'];
$opp= $_GET['OPP'];



switch($opp){

    case "+";
    echo $num1+$num2;
break;

}

// if($opp=='+'){
//     echo $num1+$num2;
// }
// elseif($opp=='-'){
//     echo $num1-$num2;
// }

// elseif($opp=='/'){
//     echo $num1/$num2;
// }
// elseif($opp=='*'){
//     echo $num1*$num2;
// }
// else {
//     echo "Invalid Input";
// }
 

?>