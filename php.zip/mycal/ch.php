<?php

//Calculator

$num1=


?>