<?php

session_start();
$fname=$_GET['first_name'];
$lname=$_GET['last_name'];
$mail=$_GET['email'];
$phone=$_GET['phone'];
$birthday=$_GET['birthday'];
$gender=$_GET['gender'];
//$username=$_GET['username'];
  $pass=$_GET['pw'];
 







      $conn= mysqli_connect('localhost','root','','table');
      
      $sql= "INSERT INTO `form`(`FirstName`, `LastName`, `Email`, `Gender`, `dob`, `conTact`, `passWord` ) VALUES ('$fname','$lname','$mail','$gender', '$birthday', '$phone', '$pass')";
      
      

      mysqli_query($conn, $sql);

       
     $_SESSION['fname']=$fname;
    // $_SESSION['mail']=$mail;
     $_SESSION['lname']=$lname;
    // $_SESSION['phone']= $phone;
    // $_SESSION['username']=$username;
    // $_SESSION['pass']=$pass;
    // $_SESSION['pw']=$pw;

    $_SESSION['email'] = $email;
    $_SESSION['phone'] =$phone;
    $_SESSION['gender']=$gender;



      header("location: login.php");

    



// mysqli_query($conn,$sql);



?>