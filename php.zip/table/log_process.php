    <?php

    session_start();
  $email=$_GET['email'];
    $pass=$_GET['pass'];
    


    //     $_SESSION['fname'];
    //     $_SESSION['mail'];
    // $_SESSION['lname'];
    // $_SESSION['phone'];
   
    // $_SESSION['pw'];


    //     if ($pw==$pass) {
    //         // header("location: table.php");
    //         echo "hello";
    //     } else {
    //         echo "Invalid input" ;

    //     }
        
        $conn= mysqli_connect('localhost','root','','table');

        $sql="SELECT * FROM `form` WHERE passWord ='$pass' and Email='$email' ";

        $result=mysqli_query($conn,$sql);
         $count=mysqli_num_rows($result);

        if($count>0){


         // fetch the columns of the table
         while($row = mysqli_fetch_assoc($result)) {


        
        $email= $row["email"];
       $pass=  $row["passWord"];
       $phone= $row["phone"];
       $birthday= $row["birthday"];
       $gender= $row["gender"];


       header("location: table.php");
       
         }
         }
         else{
             echo "Invalid input";
         }
        //  $_SESSION['fname']= $fname;
        

          


          









        ?>