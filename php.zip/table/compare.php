<?php

session_start();
$username=$_GET['username'];
    $pass=$_GET['pass'];
    $_SESSION['username']=$username;
    $_SESSION['pass']= $pass;
?>