<?php
$con = mysqli_connect("localhost", "root", "", "hey");
$errors = array(); 

// LOGIN USER
if (isset($_POST['login_user'])) {
    $username  = $_POST['name'];
    $password =  $_POST['password'];
  
    if (empty($username)) {
       die("Username is required");
    }
    if (empty($password)) {
        die("Password is required");
    }
  
    if (count($errors) == 0) {
        $password = md5($password);
        $sql = "SELECT * FROM records WHERE Username='$username' AND password='$password'";
        $results = mysqli_query($con, $sql);
        if (mysqli_num_rows($results) == 1) {
          
          header('location: page1.php');
        }else {
           die("Wrong username/password combination");
        }
    }
  }

?>