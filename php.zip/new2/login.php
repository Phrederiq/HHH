<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login</title>
</head>
<body>
    <form action="compare.php" method="post">
        <label for="name"></label>
        <input type="text" name="name" id="" placeholder="Firstname" required><br>
        <label for="password"></label>
        <input type="password" name="password" id="" placeholder="Password"><br>
        <input type="submit" value="Submit" name="login_user"><br>
    </form>
</body>
</html>