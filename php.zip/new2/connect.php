<?php
 
 session_start();

 $errors = array(); 
 $username = $_POST['name'];
 $mail = $_POST['mail'];
 $password = $_POST['password'];
 $password2 = $_POST['password2'];

$con = mysqli_connect("localhost", "root", "", "hey");


// Password confirmation
if ($password != $password2) {
	
    die ("The two passwords do not match");
}

// first check the database to make sure 
  // a user does not already exist with the same username and/or email
  $user_check_query = "SELECT * FROM records WHERE Username='$username' OR Email='$mail' LIMIT 1";
  $result = mysqli_query($con, $user_check_query);
  $user = mysqli_fetch_assoc($result);

  if ($user) { // if user exists
    if ($user['Username'] === $username) {
      die ("Username already exists");
    }

    if ($user['mail'] === $mail) {
      die("email already exists");
    }
  }

  // Finally, register user if there are no errors in the form
  else {
      //encrypt the password before saving in the database
  	$password_encrypt= md5($password_1);

      $sql = "INSERT INTO `records`(`Username`, `Email`, `password`) VALUES ('$username','$mail','$password_encrypt')";

      $result = mysqli_query($con, $sql);
      
  	header('location: page1.php');
  }

  



  




?>