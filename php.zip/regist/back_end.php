<?php

$uName= $_GET['uName'];
 $name= $_GET['name'];
$mail= $_GET['mail'];
$DOB= $_GET['DOB'];
$age= $_GET['age'];
$pword= $_GET['pword'];
$pWord= $_GET['pWord'];

// function age(){


//   $dateOfBirth = "$DOB";
//   $today = date("Y-m-d");
//   $diff = date_diff(date_create($dateOfBirth), date_create($today));
//   echo 'Your age is '.$diff->format('%y');
// }

if ($uName==$name & $pword==$pWord) {
    echo "HEY " ,$name, "!!"; 
   

} else
if ($uName==$name & $pword!=$pWord) {
    echo "WRONG PASSWORD";
} {
    # code...
}
