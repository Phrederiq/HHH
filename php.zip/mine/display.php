

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table>
<tr>
    <th>Username</th>
    <th>Password</th>
    
  </tr>


  <?PHP


$con = mysqli_connect('localhost', 'root', '', 'stuff');
// $sql = "INSERT INTO `login`(`eMail`, `passWord`) VALUES ('$mail','$pw')";
$sql = "SELECT * FROM `login`  ";

$result=mysqli_query($con,$sql);

while($row = mysqli_fetch_assoc($result)) {
    //echo "id: " . $row["eMail"]. " - Name: " . $row["passWord"]. "<br>";
 


    echo"<tr>";
echo"<td>";

echo $row["eMail"];

echo"</td>";


echo"<td>";

echo $row["passWord"];

echo"</td>";
  
     
echo"</tr>";


}



?>






 
</table>
</body>
</html>
  