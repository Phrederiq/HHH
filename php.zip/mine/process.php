<?PHP

$mail=$_POST['mail'];
$pw=$_POST['pword'];


//execute the connection
$con = mysqli_connect('localhost', 'root', '', 'stuff');



// $sql = "INSERT INTO `login`(`eMail`, `passWord`) VALUES ('$mail','$pw')";



//sql code 
  


//this is to execute the command
$result=mysqli_query($con,$sql);


// count the number of records 
$count=mysqli_num_rows($result);

if($count==1){

    // fetch the columns of the table
    while($row = mysqli_fetch_assoc($result)) {


        //columns of the table 
      $email= $row["eMail"];
      $pass=  $row["passWord"];


      //storing data from the columns into session for future use 
      $_SESSION['email']=$email;
      $_SESSION['password']=$pass;
      $_SESSION['isuserlogin']=1;

      }


//redirect to main page or dashbaord 
      
}





?>