<?php



session_start();
//include("connect.php");
include("function.php");

if($_SERVER['REQUEST_METHOD']=="POST"); 

{
    $username= $_POST['name'];
    $password = $_POST['password'];

    if (!empty($username)&& !empty($password) && !is_numeric($username))
    {
    // SAVE TO DATABASE
    $user_id = random_num(1000);
    $query = "INSERT INTO `users`(`user_id`, `user_name`, `password`) VALUES ('$user_id','$username','$password')";
        mysqli_query($con, $query);

        header("Location:login.php");
        die;
    }
    else
    {
        echo"ENTER SOME VALID INFORMATION!";
    }

}




if(!$con = mysqli_connect("localhost", "root", "", "gwcl"))
{
    die("failed to connect");
}
?>