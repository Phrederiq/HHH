<?php
//(the first value in the localhost then the root which is constant in the db then the empty bracket represents the password and finnally the name of the database)
$con=mysqli_connect("localhost","root","","school");

$sql = "INSERT INTO `regist`(`First_Name`, `Last_Name`, `Age`, `student_id`) VALUES ('Fred','drew',12,'ad112')";

mysqli_query($con, $sql);


?>