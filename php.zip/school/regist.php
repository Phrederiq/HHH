<?php 

 $fName = $_GET['fname'];
 $lName = $_GET['sname'];
 $myage = $_GET['age'];
 $sId = $_GET['s_id'];


include 'db.php';
// return;
//(the first value in the localhost then the root which is constant in the db then the empty bracket represents the password and finnally the name of the database)
 $con= mysqli_connect("localhost","root","","school");

// $sql = "INSERT INTO `regist`(`First_Name`, `Last_Name`, `Age`, `student_id`) VALUES ('$fName', '$lName', '$myage', '$sId')";

// $del = "DELETE FROM `regist` WHERE $myage=12";
$sql = "DELETE FROM regist WHERE Age= 45" ;

mysqli_query($con, $sql);



?>