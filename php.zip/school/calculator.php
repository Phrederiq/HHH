<?php 


$num1= 5;
$num2= 8;

$total =$num1 + $num2;
echo $total;
?>