<?PHP

session_start();
echo $_SESSION ['fred'];
?>