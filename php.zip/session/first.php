<?PHP

$name="Mike";

session_start();
$_SESSION ['fred'] = $name ;



?>