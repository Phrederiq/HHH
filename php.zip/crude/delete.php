<?php
    include_once 'db.php';


    $id=$_GET['id'];
 
    $sql = "DELETE FROM db_crude WHERE user_id= '$id' ";
 
    if (mysqli_query($conn, $sql)) {
 
        echo "Record deleted successfully";
 
    } else {
     
        echo "Error deleting record: " . mysqli_error($conn);
    }
    mysqli_close($conn);
?>