<?php
include_once 'db.php';
 $firstname = $_GET['firstname'];
 
 $lastname=$_GET['lastname'];
 $mobile=$_GET['mobile'];
 $id = $_GET['id'];
    
     
 
     $sql = "INSERT INTO db_crude (firstname,lastname,mobile)
     VALUES ('$firstname','$lastname','$mobile')";
 
     if (mysqli_query($conn, $sql)) {
        echo "New record has been added successfully !";
     } else {
        echo "Error: " . $sql . ":-" . mysqli_error($conn);
     }
     mysqli_close($conn);

     
 
?>