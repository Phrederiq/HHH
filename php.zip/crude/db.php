<?php
   
    $conn=mysqli_connect("localhost","root","","crude");
    if(!$conn)
        {
          die('Could not Connect MySql Server:' );
        }


?>