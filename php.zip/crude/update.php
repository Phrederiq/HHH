<?php 
 
include_once 'db.php';
 
$sql = "UPDATE db_crude SET mobile = '9874561230' WHERE firstname = 'fred' ";
 
$query = mysqli_query($conn,$sql);
if(!$query)
{
    echo "Query does not work.".mysqli_error($conn);die;
}
else
{
    echo "Data successfully updated";
}
 
   
?>