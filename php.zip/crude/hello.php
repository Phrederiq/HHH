<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="insert.php" method="get">
    <label >firstname</label> <br>
    <input type="text" name="firstname"><br>
    <label >lastname</label><br>
    <input type="text" name="lastname"><br>
    <label >mobile</label><br>
    <input type="number" name="mobile"><br>
    <label >id</label>
    <input type="text" name="id" >

    <input type="submit" value="submit"><br>
    </form>

    
</body>
</html>