<?php
 $fname=$GET_('fname');
 $lname=$GET_('lname');
 $age=$GET_('age');


 
?>