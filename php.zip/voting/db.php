<?PHP

$uname=$_GET['uname'];

$mail=$_GET['mail'];
$pw=$_GET['pw'];

$conn= mysqli_connect("localhost", "root", "", "shop");
$sql= "INSERT INTO `store`(`USERNAME`, `EMAIL`, `PASSWORD`) VALUES ('$uname','$mail','$pw')";

mysqli_query($conn,$sql);






?>