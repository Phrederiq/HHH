<?php

require ('db.php');


?>