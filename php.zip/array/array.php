<?php
// $num = array("3","5","7");
// echo $num[0];
// echo "<br>";
// echo $num[1];
// echo "<br>";
// echo $num[2];
// echo "<br>";
// echo count ($num);
// echo "<br>";
// $phones =array("tecno"=>"200", "samsung"=> "600", "iphone"=>"1000");
// echo $phones["tecno"];
// echo "<br>";
// $mypassword= "abcd@1122";

// $age=15;
// $sum =6+2;





// if($phones["tecno"]== 20 & $phones["samsung"]== 600 |$phones["iphone"]=="100"  ){


// echo"access granted";

// }

// else 
// if($sum>=9)
// {

//     echo"you are pardoned ";
// }
// else{
//       echo"access denied ";
// }



// function calculator(){

// $firstnumber=10;
// $secondNumber=20;

// $sum=$firstnumber+$secondNumber;

// if($sum>=30){
//       echo"You are right";


// }
// else {
//       echo "Try again";
// }
//return $sum;
//echo 'max';

// }
         

//echo $max=


//echo $max=calculator();



// function cars($k,$u){

//       $num1=$k;
//       $num2=$u;

//     $total=$num1+$num2;  
//  return $total;
// }



// $f=1;
// $n=2;

// echo $t=cars($f,$n);
$names= "fred";
switch($names){
    case "Paul";
      echo "its Paul ";
      break;
      case "Jake";
      echo "its Jake ";
      break;

      case "fred";
      echo "its fred";
      break;

      case "Fred";
      echo "its Fred";
      break;

      default;
      echo "Incorrect input";
      break;

}

?>